
import React from 'react';
import { AI_TOOLS } from '../constants';

const AITools: React.FC = () => {
  // Doubling the array for seamless infinite scroll
  const toolsLoop = [...AI_TOOLS, ...AI_TOOLS];

  return (
    <div className="py-32 bg-[#0a0a0a] border-y border-white/5 overflow-hidden relative">
      <div className="container mx-auto px-6 mb-20 relative z-10">
        <div className="text-center">
          <span className="text-[#007BFF] font-black uppercase tracking-[0.4em] text-[10px] mb-4 block">Ecosystem Architecture</span>
          <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tighter italic">Leveraging <span className="text-white/20">Elite Neural Tools.</span></h2>
        </div>
      </div>
      
      {/* Infinite Scrolling Marquee */}
      <div className="flex relative overflow-hidden group">
        <div className="flex animate-marquee whitespace-nowrap gap-20 md:gap-40 items-center py-10">
          {toolsLoop.map((tool, idx) => (
            <div key={`${tool.name}-${idx}`} className="flex flex-col items-center justify-center min-w-[140px] md:min-w-[200px] group/item">
              <div className="h-20 md:h-28 w-full flex items-center justify-center relative px-6">
                {/* Dynamic Glow behind the logo */}
                <div className="absolute inset-0 bg-[#007BFF]/0 group-hover/item:bg-[#007BFF]/10 blur-3xl rounded-full transition-all duration-500 scale-50 group-hover/item:scale-110"></div>
                
                <img 
                  src={tool.logo} 
                  alt={tool.name} 
                  className="max-h-full max-w-full object-contain grayscale opacity-40 group-hover/item:grayscale-0 group-hover/item:opacity-100 group-hover/item:scale-110 transition-all duration-700 relative z-10"
                />
              </div>
              <span className="mt-8 text-[10px] font-black uppercase tracking-[0.6em] text-[#007BFF] opacity-0 group-hover/item:opacity-100 transition-all translate-y-4 group-hover/item:translate-y-0 duration-500">
                {tool.name}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Aesthetic Side Fades */}
      <div className="absolute top-0 left-0 h-full w-40 bg-gradient-to-r from-[#0a0a0a] to-transparent z-20 pointer-events-none"></div>
      <div className="absolute top-0 right-0 h-full w-40 bg-gradient-to-l from-[#0a0a0a] to-transparent z-20 pointer-events-none"></div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          animation: marquee 40s linear infinite;
        }
        .animate-marquee:hover {
          animation-play-state: paused;
        }
      `}} />
    </div>
  );
};

export default AITools;
