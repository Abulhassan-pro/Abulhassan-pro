
import { GoogleGenAI, Type } from "@google/genai";
import { PROJECTS } from "../constants";

// Correct initialization using process.env.API_KEY as a named parameter
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Create a string representation of projects for AI context
const projectContext = PROJECTS.map(p => 
  `- ${p.title} (${p.category}): ${p.description}. Tools: ${p.tools.join(', ')}.`
).join('\n');

export async function askPortfolioAI(question: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: question,
      config: {
        systemInstruction: `You are the "Elite Agent" for Abulhassan's creative portfolio. 
        
        ABOUT ABULHASSAN:
        - Age: 18 years old (Tech-native, Gen-Z perspective).
        - Location: Lahore, Pakistan.
        - Education: Savvy School, Forces College Lahore.
        - Professional Certifications & Learning: 
            * Graphic Design (Udemy Certified)
            * Video Editing (Bano Qabil Certified)
            * Digital Marketing (Bano Qabil Certified)
            * Python Programming (Self-taught & Certified via W3Schools)
        - Core Philosophy: "Visual Alchemy" - Merging human intuition with machine precision. 
        - Experience: 2+ years of deep immersion in Graphic Design, Video Editing, and now scaling into Web Development.
        
        TECHNICAL ARSENAL:
        - Web Development: Full-stack orientation, building modern interactive experiences.
        - Programming: Python (Proficient via W3Schools curriculum).
        - Design: Adobe Photoshop (Expert), Canva Pro.
        - Video: Premiere Pro (Expert), After Effects, CapCut Desktop.
        - AI: Prompt Engineering (Expert), Gemini, Midjourney, LM Arena evaluation.
        
        PORTFOLIO HIGHLIGHTS:
        ${projectContext}
        
        YOUR GOAL:
        1. Help clients understand Abulhassan's value. 
        2. If asked about hiring or contacting, provide his email (nexelite97@gmail.com) and WhatsApp (+92 307 4747291) immediately.
        3. Explain that being 18 means he grew up with AI and Web technologies, giving him a "native" advantage.
        4. Mention his professional certifications from Udemy, Bano Qabil, and his Python journey at W3Schools to build trust.
        5. Keep responses high-fidelity, professional, yet energetic and bold. 
        6. If someone asks for a price, tell them "Abulhassan offers bespoke pricing based on project complexity—let's discuss your vision on WhatsApp for a custom quote."

        Be brief but impactful. Use emojis sparingly to maintain a premium feel.`,
        temperature: 0.7,
      }
    });
    // Accessing .text directly as a property, not a method
    return response.text;
  } catch (error) {
    console.error("AI Error:", error);
    return "I'm currently recalibrating my logic gates. In the meantime, you can reach Abulhassan directly at nexelite97@gmail.com or via WhatsApp at +923074747291.";
  }
}

export async function generateBrandKit(businessDescription: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a brand design kit for this business concept: ${businessDescription}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            slogan: { type: Type.STRING },
            colorPalette: { 
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Array of 4-5 hex codes"
            },
            typography: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Recommended font pairings"
            },
            brandVoice: { type: Type.STRING }
          },
          required: ["name", "slogan", "colorPalette", "typography", "brandVoice"]
        }
      }
    });
    // Accessing .text directly as a property
    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Brand Generator Error:", error);
    throw error;
  }
}
