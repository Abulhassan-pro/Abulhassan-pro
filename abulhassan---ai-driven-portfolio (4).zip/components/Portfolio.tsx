import React, { useState, useRef } from 'react';
import { PROJECTS } from '../constants';
import { Category, Project } from '../types';

const ProjectMockup: React.FC<{ project: Project }> = ({ project }) => {
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateY = ((x - centerX) / centerX) * 8; 
    const rotateX = ((centerY - y) / centerY) * 8;
    setRotation({ x: rotateX, y: rotateY });
  };

  const handleMouseLeave = () => {
    setRotation({ x: 0, y: 0 });
  };

  return (
    <div 
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="perspective-1000 group/mockup cursor-pointer mb-10"
      style={{
        transform: `perspective(1000px) rotateX(${rotation.x}deg) rotateY(${rotation.y}deg) scale(${rotation.x !== 0 || rotation.y !== 0 ? 1.02 : 1})`,
        transition: 'transform 0.1s ease-out'
      }}
    >
      <div className="relative w-full aspect-square md:aspect-video rounded-[32px] overflow-hidden border border-white/10 shadow-2xl bg-[#0a0a0a] group-hover/mockup:border-[#007BFF]/40 transition-all duration-500">
        {/* Deep Glossy Overlay */}
        <div className="absolute inset-0 z-20 pointer-events-none bg-gradient-to-tr from-white/5 via-transparent to-transparent opacity-0 group-hover/mockup:opacity-100 transition-opacity duration-700"></div>
        
        {/* Dynamic Inner Glow */}
        <div className="absolute inset-0 z-10 pointer-events-none shadow-[inset_0_0_100px_rgba(0,0,0,0.8)]"></div>
        
        {/* Scanline Effect on Hover */}
        <div className="absolute inset-0 z-30 pointer-events-none opacity-0 group-hover/mockup:opacity-[0.03] bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%] transition-opacity duration-700"></div>

        <img 
          src={project.imageUrl} 
          alt={project.title} 
          className="w-full h-full object-cover grayscale-[0.2] group-hover/mockup:grayscale-0 group-hover/mockup:scale-105 transition-all duration-1000"
        />

        {/* Professional Frame Detail */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#007BFF]/50 to-transparent opacity-0 group-hover/mockup:opacity-100 transition-opacity duration-500"></div>
      </div>
      
      {/* Floating Refraction */}
      <div className="absolute inset-0 opacity-0 group-hover/mockup:opacity-20 transition-opacity pointer-events-none bg-gradient-to-tr from-transparent via-white to-transparent blur-sm" 
           style={{ transform: `translateX(${(rotation.y * 10)}%) translateY(${(rotation.x * 10)}%)` }} />
    </div>
  );
};

const Portfolio: React.FC = () => {
  const [filter, setFilter] = useState<Category>(Category.ALL);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const filteredProjects = PROJECTS.filter(p => 
    filter === Category.ALL || p.category === filter
  );

  return (
    <div className="container mx-auto px-6">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end mb-32 gap-12">
        <div className="max-w-2xl">
          <span className="text-[#007BFF] font-black uppercase tracking-[0.3em] text-[10px] mb-6 block">Exhibition Hub</span>
          <h2 className="text-6xl md:text-8xl font-black uppercase tracking-tighter leading-[0.8] mb-10">Selected <br /> <span className="text-white/20">Artifacts.</span></h2>
          <p className="text-gray-400 text-xl leading-relaxed">Precision-engineered visual assets. A showcase of elite visual alchemy and digital narrative power.</p>
        </div>
        
        <div className="flex flex-wrap gap-2 glass p-2.5 rounded-full border-white/5">
          {Object.values(Category).map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-10 py-4 rounded-full text-[11px] font-black uppercase tracking-widest transition-all ${
                filter === cat 
                ? 'bg-[#007BFF] text-white glow-blue shadow-lg' 
                : 'text-gray-500 hover:text-white hover:bg-white/5'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-16">
        {filteredProjects.map((project, idx) => (
          <div 
            key={project.id} 
            className="group cursor-pointer flex flex-col transition-all duration-500 relative"
            onClick={() => setSelectedProject(project)}
          >
            {/* Project Index Numbering */}
            <div className="absolute -top-10 -left-6 text-9xl font-black text-white/[0.03] pointer-events-none select-none italic">
              0{idx + 1}
            </div>

            <ProjectMockup project={project} />
            
            <div className="px-2 mt-auto">
               <div className="flex items-center justify-between mb-5">
                  <div className="flex gap-2">
                    {project.tools.slice(0, 2).map(tool => (
                      <span key={tool} className="text-[10px] uppercase font-black text-white/40 bg-white/5 px-3 py-1.5 rounded-lg border border-white/5">
                        {tool}
                      </span>
                    ))}
                  </div>
                  <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center text-lg text-white/40 group-hover:bg-[#007BFF] group-hover:text-white group-hover:border-[#007BFF] group-hover:scale-110 transition-all shadow-xl">
                    ↗
                  </div>
               </div>
               <h3 className="text-2xl font-black mb-3 group-hover:text-[#007BFF] transition-colors uppercase tracking-tight italic">{project.title}</h3>
               <p className="text-gray-500 text-md line-clamp-2 leading-relaxed font-medium">
                 {project.description}
               </p>
            </div>
          </div>
        ))}
      </div>

      {/* Modern Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-[#080808]/98 backdrop-blur-3xl" onClick={() => setSelectedProject(null)}></div>
          <div className="relative glass w-full max-w-7xl max-h-[92vh] overflow-hidden rounded-[50px] border-white/10 flex flex-col lg:flex-row shadow-[0_50px_150px_-30px_rgba(0,123,255,0.4)]">
            <button 
              onClick={() => setSelectedProject(null)}
              className="absolute top-10 right-10 w-16 h-16 rounded-full glass border-white/20 flex items-center justify-center text-white hover:bg-white/10 z-[1010] transition-transform active:scale-90 shadow-2xl"
            >
              ✕
            </button>
            
            <div className="lg:w-3/5 h-full bg-[#040404] flex items-center justify-center p-8 lg:p-16 overflow-hidden relative">
               <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#007BFF 1px, transparent 1px)', backgroundSize: '30px 30px' }}></div>
               <div className="w-full h-full rounded-[32px] overflow-hidden border border-white/10">
                  <img src={selectedProject.imageUrl} className="w-full h-full object-cover" alt={selectedProject.title} />
               </div>
            </div>
            
            <div className="lg:w-2/5 p-16 md:p-20 flex flex-col justify-center bg-black/50 overflow-y-auto border-l border-white/5">
              <span className="text-[#007BFF] font-black uppercase tracking-[0.4em] text-[11px] mb-8 block">Project Briefing</span>
              <h2 className="text-5xl md:text-7xl font-black mb-10 leading-[0.8] uppercase italic tracking-tighter">{selectedProject.title}</h2>
              <p className="text-gray-400 text-xl mb-12 leading-relaxed font-medium">
                {selectedProject.longDescription || selectedProject.description}
                <br /><br />
                Strategically engineered to maximize visual fidelity and narrative impact.
              </p>
              
              <div className="mb-14">
                <h4 className="text-white text-xs font-black uppercase tracking-[0.3em] mb-8">Technical Stack</h4>
                <div className="flex flex-wrap gap-4">
                  {selectedProject.tools.map(tool => (
                    <span key={tool} className="bg-white/5 px-8 py-4 rounded-2xl text-[11px] font-black uppercase tracking-widest border border-white/10 shadow-lg">{tool}</span>
                  ))}
                </div>
              </div>

              {selectedProject.videoUrl && (
                <div className="mb-8">
                  <a 
                    href={selectedProject.videoUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-4 w-full bg-[#007BFF] text-white py-8 rounded-[32px] font-black uppercase tracking-[0.2em] text-center text-sm hover:bg-[#006ae0] transition-all glow-blue mb-4 shadow-2xl active:scale-95"
                  >
                    <span className="text-2xl">▶</span> Play Production Reel
                  </a>
                </div>
              )}
              
              <a href="#contact" onClick={() => setSelectedProject(null)} className={`w-full ${selectedProject.videoUrl ? 'bg-white/5 text-white border border-white/10' : 'bg-white text-black'} py-8 rounded-[32px] font-black uppercase tracking-[0.2em] text-center text-sm hover:bg-[#007BFF] hover:text-white hover:border-[#007BFF] transition-all shadow-xl active:scale-95`}>
                Commission similar work
              </a>
            </div>
          </div>
        </div>
      )}

      <style dangerouslySetInnerHTML={{ __html: `
        .perspective-1000 { perspective: 1000px; }
        .preserve-3d { transform-style: preserve-3d; }
      `}} />
    </div>
  );
};

export default Portfolio;