
import React, { useState } from 'react';
import { generateBrandKit } from '../services/gemini';
import { BrandKit } from '../types';

const BrandGenerator: React.FC = () => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [kit, setKit] = useState<BrandKit | null>(null);

  const handleGenerate = async () => {
    if (!input.trim()) return;
    setLoading(true);
    setKit(null);
    try {
      const result = await generateBrandKit(input);
      setKit(result);
    } catch (e) {
      alert("Failed to generate brand kit. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-6 py-20 bg-[#0c0c0c] rounded-[60px] my-20 border border-white/5">
      <div className="max-w-4xl mx-auto text-center">
        <span className="text-[#007BFF] font-bold uppercase tracking-widest text-xs mb-4 block">Interactive Experiment</span>
        <h2 className="text-4xl md:text-6xl font-black mb-8">AI Brand Strategist</h2>
        <p className="text-gray-400 text-lg mb-12">
          Experience Abulhassan's AI logic in action. Describe your business idea below, and his customized model will generate a brand concept for you.
        </p>
        
        <div className="flex flex-col md:flex-row gap-4 mb-16">
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="e.g., A minimalist coffee shop for digital nomads"
            className="flex-1 glass bg-white/5 rounded-2xl px-8 py-5 focus:border-[#007BFF] focus:outline-none transition-all text-lg"
          />
          <button 
            onClick={handleGenerate}
            disabled={loading}
            className="bg-[#007BFF] px-12 py-5 rounded-2xl font-black text-lg hover:bg-[#0056b3] transition-all glow-blue disabled:opacity-50"
          >
            {loading ? "Strategizing..." : "Generate Kit"}
          </button>
        </div>

        {kit && (
          <div className="text-left glass p-10 rounded-[40px] animate-fade-in border-[#007BFF]/20">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div>
                <h3 className="text-xs font-bold text-[#007BFF] uppercase tracking-[0.2em] mb-2">Business Name</h3>
                <p className="text-3xl font-black mb-6">{kit.name}</p>
                
                <h3 className="text-xs font-bold text-[#007BFF] uppercase tracking-[0.2em] mb-2">Slogan</h3>
                <p className="text-xl italic text-gray-300 mb-8">"{kit.slogan}"</p>
                
                <h3 className="text-xs font-bold text-[#007BFF] uppercase tracking-[0.2em] mb-2">Voice & Tone</h3>
                <p className="text-gray-400 leading-relaxed">{kit.brandVoice}</p>
              </div>
              
              <div className="space-y-8">
                <div>
                  <h3 className="text-xs font-bold text-[#007BFF] uppercase tracking-[0.2em] mb-4">Color Palette</h3>
                  <div className="flex gap-4">
                    {kit.colorPalette.map(color => (
                      <div key={color} className="flex flex-col items-center gap-2">
                        <div 
                          className="w-16 h-16 rounded-2xl shadow-lg border border-white/10" 
                          style={{ backgroundColor: color }}
                        ></div>
                        <span className="text-[10px] font-mono text-gray-500 uppercase">{color}</span>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-xs font-bold text-[#007BFF] uppercase tracking-[0.2em] mb-4">Typography Pairing</h3>
                  <div className="space-y-4">
                    {kit.typography.map((font, idx) => (
                      <div key={idx} className="p-4 glass rounded-xl border-white/5">
                        <p className="text-xs text-gray-500 mb-1">{idx === 0 ? 'Primary' : 'Secondary'}</p>
                        <p className="text-lg font-bold">{font}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-12 pt-12 border-t border-white/5 flex justify-center">
              <button className="text-[#007BFF] font-bold hover:underline underline-offset-8" onClick={() => window.print()}>
                Export Concept Briefing
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BrandGenerator;
