
import React, { useState, useEffect } from 'react';
import emailjs from '@emailjs/browser';

const Contact: React.FC = () => {
  const [status, setStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    project: 'Graphic Design',
    message: ''
  });

  useEffect(() => {
    // Initialize EmailJS with your Public Key
    emailjs.init("SJaoCHzqYHcEb3rEb");
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;
    
    setStatus('sending');
    
    try {
      // Map form data to template parameters
      const templateParams = {
        from_name: formData.name,
        from_email: formData.email,
        project_type: formData.project,
        message: formData.message,
        to_name: "Abulhassan", // Standard field for many templates
      };

      const result = await emailjs.send(
        "service_sclkr9b",
        "template_nhlayu6",
        templateParams
      );

      if (result.status === 200) {
        setStatus('success');
        setFormData({ name: '', email: '', project: 'Graphic Design', message: '' });
        // Auto-reset after success message
        setTimeout(() => setStatus('idle'), 6000);
      } else {
        throw new Error("Failed to send message");
      }
    } catch (error) {
      console.error('EmailJS Error:', error);
      setStatus('error');
      setTimeout(() => setStatus('idle'), 4000);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <div className="container mx-auto px-6">
      <div className="max-w-6xl mx-auto flex flex-col lg:flex-row gap-20">
        <div className="w-full lg:w-1/2">
          <h2 className="text-5xl font-black mb-6 leading-tight uppercase tracking-tighter italic">
            Ready to <span className="text-[#007BFF]">level up</span> <br /> your brand?
          </h2>
          <p className="text-gray-400 text-lg mb-12 max-w-md">
            I'm currently available for high-fidelity freelance projects and strategic collaborations. Let's engineer something extraordinary.
          </p>
          
          <div className="space-y-8">
            <a href="mailto:nexelite97@gmail.com" className="flex items-start gap-6 group cursor-pointer">
              <div className="w-14 h-14 rounded-2xl bg-[#007BFF]/10 flex items-center justify-center text-[#007BFF] group-hover:bg-[#007BFF] group-hover:text-white transition-all shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-1">Email</h4>
                <p className="text-xl font-black tracking-tight group-hover:text-[#007BFF] transition-colors">nexelite97@gmail.com</p>
              </div>
            </a>
            
            <a href="https://wa.me/923074747291" target="_blank" rel="noopener noreferrer" className="flex items-start gap-6 group cursor-pointer">
              <div className="w-14 h-14 rounded-2xl bg-[#007BFF]/10 flex items-center justify-center text-[#007BFF] group-hover:bg-[#25D366] group-hover:text-white transition-all shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.417-.003 6.557-5.338 11.892-11.893 11.892-1.997-.001-3.951-.5-5.688-1.448l-6.305 1.652zm6.599-3.835c1.558.925 3.31 1.414 5.099 1.415 5.387 0 9.771-4.384 9.774-9.77.001-2.607-1.015-5.059-2.861-6.905-1.847-1.847-4.296-2.863-6.905-2.864-5.388 0-9.773 4.385-9.776 9.77-.001 1.83.48 3.614 1.391 5.174l-.913 3.334 3.413-.895zm10.513-7.234c-.26-.13-1.536-.757-1.774-.843-.239-.087-.413-.13-.587.13-.174.26-.673.843-.825 1.017-.152.174-.304.195-.564.065-.26-.13-1.097-.404-2.09-1.289-.773-.689-1.294-1.541-1.446-1.801-.152-.26-.016-.4.114-.529.117-.117.26-.304.39-.456.13-.152.174-.26.26-.434.087-.174.043-.326-.022-.456-.065-.13-.587-1.412-.804-1.933-.211-.51-.427-.44-.587-.448-.152-.008-.326-.009-.5-.009s-.456.065-.695.326c-.239.26-.913.891-.913 2.173s.934 2.52 1.065 2.694c.13.174 1.838 2.808 4.454 3.935.622.268 1.107.428 1.486.548.624.198 1.192.17 1.64.103.499-.075 1.536-.627 1.753-1.233.217-.606.217-1.127.152-1.233-.065-.106-.239-.17-.499-.3z"/></svg>
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-1">WhatsApp</h4>
                <p className="text-xl font-black tracking-tight group-hover:text-[#25D366] transition-colors">+92 307 4747291</p>
              </div>
            </a>
            
            <div className="flex items-start gap-6 group">
              <div className="w-14 h-14 rounded-2xl bg-[#007BFF]/10 flex items-center justify-center text-[#007BFF] group-hover:bg-[#007BFF] group-hover:text-white transition-all shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-1">Location</h4>
                <p className="text-xl font-black tracking-tight">Lahore, Pakistan</p>
              </div>
            </div>
          </div>
        </div>

        <div className="w-full lg:w-1/2">
          <form onSubmit={handleSubmit} className="glass p-10 rounded-[40px] border-[#007BFF]/20 space-y-6 relative overflow-hidden shadow-2xl">
            {status === 'success' && (
              <div className="absolute inset-0 z-50 bg-[#007BFF] flex flex-col items-center justify-center text-white p-10 text-center animate-fade-in transition-all">
                <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center mb-8 text-5xl animate-bounce shadow-inner">
                  ✓
                </div>
                <h3 className="text-4xl font-black uppercase tracking-tighter mb-6 italic">Transmission Sent</h3>
                <p className="font-bold text-lg opacity-90 mb-10">Your visual briefing has been received via EmailJS. Abulhassan will respond within 24h.</p>
                <button 
                  onClick={() => setStatus('idle')} 
                  className="px-12 py-4 bg-white text-black rounded-full font-black text-xs uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-xl"
                >
                  Send Another
                </button>
              </div>
            )}

            {status === 'error' && (
              <div className="absolute inset-0 z-50 bg-red-600 flex flex-col items-center justify-center text-white p-10 text-center animate-fade-in transition-all">
                <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center mb-8 text-5xl animate-shake">
                  ⚠
                </div>
                <h3 className="text-4xl font-black uppercase tracking-tighter mb-6 italic">Failed</h3>
                <p className="font-bold text-lg opacity-90 mb-10">Something went wrong with the transmission. Please check your network or try again.</p>
                <button 
                  onClick={() => setStatus('idle')} 
                  className="px-12 py-4 bg-white text-black rounded-full font-black text-xs uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-xl"
                >
                  Try Again
                </button>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 ml-1">Full Name</label>
                <input required name="name" value={formData.name} onChange={handleChange} type="text" placeholder="Your Name" className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 focus:border-[#007BFF] focus:bg-white/10 focus:outline-none transition-all" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 ml-1">Email Address</label>
                <input required name="email" value={formData.email} onChange={handleChange} type="email" placeholder="email@address.com" className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 focus:border-[#007BFF] focus:bg-white/10 focus:outline-none transition-all" />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 ml-1">Service Required</label>
              <select name="project" value={formData.project} onChange={handleChange} className="w-full bg-[#121212] border border-white/10 rounded-2xl px-6 py-4 focus:border-[#007BFF] focus:outline-none transition-all appearance-none text-white font-bold cursor-pointer">
                <option>Graphic Design</option>
                <option>Video Editing</option>
                <option>Prompt Engineering</option>
                <option>AI Brand Strategy</option>
              </select>
            </div>
            
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 ml-1">Vision Summary</label>
              <textarea name="message" value={formData.message} onChange={handleChange} rows={5} placeholder="Describe the outcome you desire..." className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 focus:border-[#007BFF] focus:bg-white/10 focus:outline-none transition-all resize-none"></textarea>
            </div>
            
            <button 
              type="submit" 
              disabled={status === 'sending'}
              className="w-full bg-[#007BFF] text-white py-6 rounded-2xl font-black text-xs uppercase tracking-[0.3em] hover:bg-[#0056b3] transition-all glow-blue flex items-center justify-center gap-4 disabled:opacity-50 group active:scale-[0.98]"
            >
              {status === 'sending' ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Broadcasting...
                </>
              ) : (
                <>
                  Initiate Transmission
                  <span className="group-hover:translate-x-2 transition-transform">→</span>
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;
