
import React, { useState, useRef, useEffect } from 'react';
import { askPortfolioAI } from '../services/gemini';
import { Message } from '../types';

const AIAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: "Welcome. I am Abulhassan's AI Agent. How can I help you scale your brand's visual identity today?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (customMessage?: string) => {
    const messageToSend = customMessage || input;
    if (!messageToSend.trim() || isLoading) return;
    
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: messageToSend }]);
    setIsLoading(true);

    const aiResponse = await askPortfolioAI(messageToSend);
    setMessages(prev => [...prev, { role: 'assistant', content: aiResponse }]);
    setIsLoading(false);
  };

  const quickActions = [
    "How can I hire you?",
    "Tell me about your AI skills",
    "Show me your video work",
    "What is your pricing?"
  ];

  return (
    <div className="fixed bottom-8 right-8 z-[100]">
      {isOpen ? (
        <div className="glass w-80 md:w-96 h-[600px] rounded-[32px] overflow-hidden flex flex-col shadow-2xl border-[#007BFF]/30 animate-scale-up">
          <div className="p-6 bg-[#007BFF] text-white flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center animate-pulse">
                🤖
              </div>
              <div>
                <h3 className="font-bold text-sm leading-tight">Elite Portfolio Agent</h3>
                <p className="text-[10px] opacity-80 uppercase tracking-widest font-black">Online & Ready</p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:rotate-90 transition-transform p-2">
              ✕
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] px-5 py-3 rounded-2xl text-sm leading-relaxed ${
                  msg.role === 'user' 
                  ? 'bg-[#007BFF] text-white rounded-tr-none' 
                  : 'bg-white/5 border border-white/10 text-gray-200 rounded-tl-none'
                }`}>
                  {msg.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white/5 border border-white/10 text-gray-400 px-5 py-3 rounded-2xl rounded-tl-none text-sm animate-pulse">
                  Analyzing request...
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Quick Actions */}
          {!isLoading && messages.length < 5 && (
            <div className="px-6 py-2 flex flex-wrap gap-2">
              {quickActions.map(action => (
                <button 
                  key={action}
                  onClick={() => handleSend(action)}
                  className="text-[10px] font-black uppercase tracking-wider bg-white/5 hover:bg-[#007BFF]/20 border border-white/10 rounded-full px-4 py-2 transition-all"
                >
                  {action}
                </button>
              ))}
            </div>
          )}
          
          <div className="p-4 border-t border-white/10 flex gap-2">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask about projects, skills, or rates..."
              className="flex-1 bg-white/5 rounded-2xl px-5 py-3 text-sm focus:outline-none focus:ring-1 ring-[#007BFF] transition-all"
            />
            <button 
              onClick={() => handleSend()}
              className="bg-[#007BFF] hover:bg-[#006ae0] w-12 h-12 rounded-2xl flex items-center justify-center transition-all active:scale-90"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
              </svg>
            </button>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="group relative w-16 h-16 bg-[#007BFF] rounded-full flex items-center justify-center text-3xl shadow-xl glow-blue hover:scale-110 transition-all duration-500"
        >
          <span className="relative z-10">🤖</span>
          <div className="absolute inset-0 bg-[#007BFF] rounded-full animate-ping opacity-25 group-hover:opacity-0"></div>
          <div className="absolute -top-12 right-0 bg-white text-black px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
            Ask My Agent
          </div>
        </button>
      )}
    </div>
  );
};

export default AIAssistant;
