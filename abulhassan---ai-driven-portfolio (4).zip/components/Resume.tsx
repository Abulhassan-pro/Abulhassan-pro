
import React, { useState } from 'react';
import { SKILLS } from '../constants';

const Resume: React.FC = () => {
  const [tilt, setTilt] = useState({ x: 0, y: 0, target: -1 });

  const handleMouseMove = (e: React.MouseEvent, id: number) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 10;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * -10;
    setTilt({ x, y, target: id });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0, target: -1 });
  };

  const education = [
    { year: "2024", title: "Python Programming", school: "W3Schools (Certified Learning)" },
    { year: "2024", title: "Video Editing", school: "Bano Qabil Professional" },
    { year: "2024", title: "Graphic Design", school: "Udemy Certified" },
    { year: "2024", title: "Digital Marketing", school: "Bano Qabil Certified" },
    { year: "2023 - 2025", title: "Higher Secondary", school: "Forces College, Lahore" },
    { year: "2021 - 2023", title: "Matriculation", school: "Savvy School" }
  ];

  return (
    <div className="container mx-auto px-6 perspective-1000">
      <div className="mb-20">
        <span className="text-[#007BFF] font-black uppercase tracking-widest text-xs mb-4 block">Qualifications</span>
        <h2 className="text-5xl md:text-7xl font-black uppercase tracking-tighter">Arsenal <span className="text-white/20">&</span> Journey</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Education Bento Box */}
        <div 
          onMouseMove={(e) => handleMouseMove(e, 0)}
          onMouseLeave={handleMouseLeave}
          className="md:col-span-4 bg-white/5 rounded-[40px] p-10 border border-white/10 group hover:border-[#007BFF]/30 transition-all duration-300 ease-out"
          style={{ 
            transform: tilt.target === 0 ? `rotateX(${tilt.y}deg) rotateY(${tilt.x}deg) scale(1.02)` : 'rotateX(0) rotateY(0) scale(1)',
            transformStyle: 'preserve-3d'
          }}
        >
          <h3 className="text-2xl font-black mb-8 uppercase" style={{ transform: 'translateZ(20px)' }}>Certifications & Education</h3>
          <div className="space-y-8" style={{ transform: 'translateZ(10px)' }}>
            {education.map((edu, idx) => (
              <div key={idx} className="relative pl-6 border-l border-l-white/10 group-hover:border-l-[#007BFF]/20 transition-all">
                <div className="absolute -left-1.5 top-0 w-3 h-3 rounded-full bg-white/20 group-hover:bg-[#007BFF] transition-all"></div>
                <p className="text-[#007BFF] font-black text-[10px] uppercase mb-1">{edu.year}</p>
                <h4 className="font-bold text-lg mb-1">{edu.title}</h4>
                <p className="text-gray-500 text-sm">{edu.school}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Skills Bento Box */}
        <div className="md:col-span-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {SKILLS.map((skill, idx) => (
            <div 
              key={skill.name} 
              onMouseMove={(e) => handleMouseMove(e, idx + 1)}
              onMouseLeave={handleMouseLeave}
              className="bg-white/5 rounded-[32px] p-8 border border-white/5 hover:bg-white/[0.08] transition-all group duration-300 ease-out"
              style={{ 
                transform: tilt.target === (idx + 1) ? `rotateX(${tilt.y}deg) rotateY(${tilt.x}deg) scale(1.05)` : 'rotateX(0) rotateY(0) scale(1)',
                transformStyle: 'preserve-3d'
              }}
            >
              <div className="flex items-center justify-between mb-4" style={{ transform: 'translateZ(30px)' }}>
                <span className="text-3xl grayscale group-hover:grayscale-0 transition-all">{skill.icon}</span>
                <span className="text-[10px] font-black text-white/30">{skill.level}%</span>
              </div>
              <h4 className="font-black text-sm uppercase tracking-wider mb-4 group-hover:text-[#007BFF] transition-colors" style={{ transform: 'translateZ(20px)' }}>{skill.name}</h4>
              <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden" style={{ transform: 'translateZ(10px)' }}>
                <div 
                  className="h-full bg-gradient-to-r from-[#007BFF] to-cyan-400 group-hover:from-white group-hover:to-[#007BFF] transition-all duration-700"
                  style={{ width: `${skill.level}%` }}
                ></div>
              </div>
            </div>
          ))}
          
          {/* AI Explorer Card */}
          <div className="sm:col-span-2 lg:col-span-1 bg-gradient-to-br from-[#007BFF] to-cyan-600 rounded-[32px] p-8 text-white relative overflow-hidden group shadow-xl">
            <div className="absolute -right-4 -bottom-4 opacity-10 text-9xl font-black uppercase tracking-tighter group-hover:scale-110 transition-transform">AI</div>
            <h4 className="font-black text-lg uppercase mb-4 relative z-10">Prompt Master</h4>
            <p className="text-white/80 text-sm leading-relaxed relative z-10">
              Expert in LM Arena, Gemini, and Midjourney evaluation. Crafting the invisible engine behind the visuals.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Resume;
