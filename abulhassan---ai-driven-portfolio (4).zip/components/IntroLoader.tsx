
import React, { useState, useEffect, useRef } from 'react';

const IntroLoader: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [stage, setStage] = useState('SYSTEM_INIT');
  const [isExiting, setIsExiting] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const onCompleteRef = useRef(onComplete);

  useEffect(() => {
    onCompleteRef.current = onComplete;
  }, [onComplete]);

  // System Protocol Logs Simulation
  const protocolLogs = [
    "MOUNTING_NEURAL_CORE...",
    "HANDSHAKE_ESTABLISHED_SSLv3",
    "DECRYPTING_VISUAL_ARTIFACTS...",
    "BYPASSING_TRADITIONAL_UX...",
    "AUTHORIZING_AGENT_ABULHASSAN...",
    "SYNTESIZING_CREATIVE_LOGIC...",
    "ALLOCATING_GPU_BUFFERS...",
    "CALIBRATING_AESTHETIC_VECTORS...",
    "OPTIMIZING_NEURAL_PATHWAYS...",
    "ACCESS_GRANTED_SOVEREIGN_USER"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        const increment = Math.floor(Math.random() * 5) + 1;
        return Math.min(prev + increment, 100);
      });
    }, 80);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Add logs based on progress
    const logIdx = Math.floor((progress / 100) * protocolLogs.length);
    if (protocolLogs[logIdx] && !logs.includes(protocolLogs[logIdx])) {
      setLogs(prev => [...prev.slice(-4), protocolLogs[logIdx]]);
      setStage(protocolLogs[logIdx].replace('_', ' '));
    }

    if (progress >= 100) {
      const timer = setTimeout(() => {
        setIsExiting(true);
        const completeTimer = setTimeout(() => {
          onCompleteRef.current();
        }, 800);
        return () => clearTimeout(completeTimer);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [progress]);

  return (
    <div className={`fixed inset-0 z-[5000] bg-[#050505] flex flex-col items-center justify-center transition-all duration-700 ease-[cubic-bezier(0.85,0,0.15,1)] ${isExiting ? 'opacity-0 scale-110 blur-xl pointer-events-none' : 'opacity-100'}`}>
      
      {/* HUD Background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Kinetic Data Waterfall */}
        <div className="absolute top-0 left-10 h-full w-px bg-gradient-to-b from-transparent via-[#007BFF]/20 to-transparent"></div>
        <div className="absolute top-0 right-10 h-full w-px bg-gradient-to-b from-transparent via-[#007BFF]/20 to-transparent"></div>
        
        {/* Scanning Hex Grid Overlay */}
        <div className="absolute inset-0 opacity-[0.03]" style={{ 
          backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', 
          backgroundSize: '40px 40px' 
        }}></div>

        {/* Diagonal Scanning Line */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#007BFF]/5 to-transparent h-20 w-full animate-scan pointer-events-none"></div>
      </div>

      <div className="relative z-10 w-full max-w-4xl px-12">
        {/* Top HUD Frame */}
        <div className="flex justify-between items-center mb-20 opacity-40">
          <div className="flex items-center gap-4">
            <div className="w-2 h-2 bg-[#007BFF] animate-ping rounded-full"></div>
            <span className="text-[10px] font-black tracking-[0.5em] text-white">CONNECTION_ENCRYPTED_AES256</span>
          </div>
          <div className="text-[10px] font-black tracking-[0.5em] text-white">STATUS: SYNTHESIZING</div>
        </div>

        {/* Centerpiece: Glitch Title */}
        <div className="text-center mb-16 relative">
          <h1 className={`text-5xl md:text-9xl font-black uppercase tracking-tighter italic mb-4 transition-all duration-300 ${progress < 100 ? 'animate-glitch' : ''}`}>
            ABUL<span className="text-[#007BFF]">HASSAN</span>
          </h1>
          <div className="h-px w-32 bg-[#007BFF] mx-auto animate-pulse"></div>
        </div>

        {/* HUD Data Panel */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 items-center">
          
          {/* Progress Circle Visualizer */}
          <div className="md:col-span-4 flex justify-center">
            <div className="relative w-40 h-40 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90">
                <circle cx="80" cy="80" r="70" fill="transparent" stroke="rgba(255,255,255,0.05)" strokeWidth="4" />
                <circle 
                  cx="80" cy="80" r="70" 
                  fill="transparent" 
                  stroke="#007BFF" 
                  strokeWidth="4" 
                  strokeDasharray="440"
                  strokeDashoffset={440 - (440 * progress) / 100}
                  className="transition-all duration-300 ease-out"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-black italic text-white leading-none">{progress}</span>
                <span className="text-[8px] font-bold text-[#007BFF] tracking-[0.3em] uppercase mt-1">PERCENT</span>
              </div>
              {/* Spinning Ring */}
              <div className="absolute inset-0 border border-dashed border-[#007BFF]/30 rounded-full animate-[spin_10s_linear_infinite]"></div>
            </div>
          </div>

          {/* System Logs Terminal */}
          <div className="md:col-span-8 bg-white/[0.02] border border-white/5 p-8 rounded-3xl backdrop-blur-3xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4">
               <div className="flex gap-1">
                 <div className="w-1.5 h-1.5 rounded-full bg-white/10"></div>
                 <div className="w-1.5 h-1.5 rounded-full bg-white/10"></div>
                 <div className="w-1.5 h-1.5 rounded-full bg-[#007BFF]"></div>
               </div>
            </div>

            <div className="space-y-3 font-mono">
              {logs.map((log, i) => (
                <div key={i} className="flex gap-4 items-center animate-fade-in">
                  <span className="text-[#007BFF] text-[10px] opacity-50">[{new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}]</span>
                  <span className={`text-[11px] font-bold tracking-wider uppercase ${i === logs.length - 1 ? 'text-white' : 'text-white/20'}`}>
                    {log}
                    {i === logs.length - 1 && <span className="animate-pulse">_</span>}
                  </span>
                </div>
              ))}
            </div>

            <div className="mt-8 pt-6 border-t border-white/5 flex justify-between items-center">
              <span className="text-[9px] font-black text-white/30 tracking-[0.2em] uppercase">Core: Stable</span>
              <div className="flex gap-4">
                 <div className="h-1 w-8 bg-[#007BFF]/50 rounded-full"></div>
                 <div className="h-1 w-8 bg-[#007BFF]/50 rounded-full"></div>
                 <div className="h-1 w-8 bg-[#007BFF] rounded-full animate-pulse"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom HUD Bar */}
        <div className="mt-20 flex flex-col items-center gap-4 opacity-50">
          <p className="text-[9px] font-bold tracking-[0.6em] text-white/40 uppercase">Aura Presence Detected // Authorization Level: ARCHITECT</p>
          <div className="w-px h-12 bg-gradient-to-b from-[#007BFF] to-transparent"></div>
        </div>
      </div>

      {/* CRT Scanline FX Overlay */}
      <div className="absolute inset-0 pointer-events-none z-[6000] opacity-[0.05] overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%]"></div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes scan {
          from { transform: translateY(-100%); }
          to { transform: translateY(1000%); }
        }
        .animate-scan {
          animation: scan 4s linear infinite;
        }
        @keyframes glitch {
          0% { transform: skew(0deg); }
          20% { transform: skew(2deg); filter: hue-rotate(90deg); }
          21% { transform: skew(-10deg); filter: blur(1px); }
          22% { transform: skew(0deg); filter: none; }
          60% { transform: skew(0deg); }
          61% { transform: skew(5deg); filter: brightness(1.5); }
          62% { transform: skew(0deg); filter: none; }
          100% { transform: skew(0deg); }
        }
        .animate-glitch {
          animation: glitch 1s infinite linear alternate-reverse;
        }
        .animate-fade-in {
          animation: fadeIn 0.5s ease-out forwards;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateX(-10px); }
          to { opacity: 1; transform: translateX(0); }
        }
      `}} />
    </div>
  );
};

export default IntroLoader;
