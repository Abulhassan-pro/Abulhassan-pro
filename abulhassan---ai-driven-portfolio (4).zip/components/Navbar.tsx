import React, { useState, useEffect } from 'react';

interface NavbarProps {
  activeSection: string;
}

const Navbar: React.FC<NavbarProps> = ({ activeSection }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      const progress = (window.scrollY / totalScroll) * 100;
      setScrollProgress(progress);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Home', id: 'home' },
    { name: 'About', id: 'about' },
    { name: 'Portfolio', id: 'portfolio' },
    { name: 'Resume', id: 'resume' },
    { name: 'Contact', id: 'contact' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 100,
        behavior: 'smooth'
      });
    }
    setIsMenuOpen(false);
  };

  return (
    <nav className={`fixed left-1/2 -translate-x-1/2 z-[100] transition-all duration-500 w-[95%] max-w-7xl ${scrolled ? 'top-4' : 'top-8'}`}>
      {/* Main Navbar Bar */}
      <div className={`glass rounded-full px-6 py-3 flex items-center justify-between transition-all duration-500 relative z-20 ${scrolled ? 'shadow-2xl border-white/10' : 'shadow-none'}`}>
        {/* Scroll Progress Indicator Line */}
        <div className="absolute bottom-0 left-6 right-6 h-[2px] bg-white/5 overflow-hidden rounded-full">
          <div 
            className="h-full bg-[#007BFF] transition-all duration-100 ease-out glow-blue" 
            style={{ width: `${scrollProgress}%` }}
          />
        </div>

        <div className="flex items-center gap-4">
          <div className="relative group cursor-pointer">
            <div className="absolute inset-0 bg-[#007BFF] blur-md opacity-0 group-hover:opacity-40 transition-opacity rounded-full"></div>
            <img 
              src="https://img.sanishtech.com/u/0caae60e7f80d894a87e90796ff86300.png" 
              alt="Abulhassan" 
              className="w-10 h-10 rounded-full border border-white/20 object-cover object-center relative z-10"
            />
          </div>
          <a href="#home" onClick={(e) => handleNavClick(e, 'home')} className="text-xl font-black tracking-tight hidden sm:block">
            ABUL<span className="text-[#007BFF]">HASSAN</span>
          </a>
        </div>
        
        {/* Desktop Links */}
        <div className="hidden lg:flex items-center gap-1">
          {navItems.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              onClick={(e) => handleNavClick(e, item.id)}
              className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition-all hover:bg-white/5 ${
                activeSection === item.id ? 'text-[#007BFF] bg-white/5' : 'text-gray-400 hover:text-white'
              }`}
            >
              {item.name}
            </a>
          ))}
        </div>
        
        <div className="flex items-center gap-3">
          {/* Social Icons for Desktop */}
          <div className="hidden lg:flex items-center gap-2 mr-2">
            <a 
              href="https://github.com/Abulhassan-pro" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-10 h-10 flex items-center justify-center rounded-full glass hover:bg-white hover:text-black transition-all group border-white/10"
              title="GitHub"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"></path><path d="M9 18c-4.51 2-5-2-7-2"></path></svg>
            </a>
            <a 
              href="https://www.linkedin.com/in/abul-hassan-844a09378/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-10 h-10 flex items-center justify-center rounded-full glass hover:bg-[#0077b5] hover:text-white transition-all group border-white/10"
              title="LinkedIn"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect width="4" height="12" x="2" y="9"></rect><circle cx="4" cy="4" r="2"></circle></svg>
            </a>
          </div>

          <a 
            href="#contact" 
            onClick={(e) => handleNavClick(e, 'contact')}
            className="bg-[#007BFF] hover:bg-[#006ae0] text-white px-6 py-2.5 rounded-full text-xs font-black uppercase tracking-widest transition-all glow-blue hover:scale-105 active:scale-95 hidden sm:block"
          >
            Hire Me
          </a>
          
          <button 
            className="lg:hidden text-white p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle Menu"
          >
            <div className="w-6 h-5 flex flex-col justify-between">
              <span className={`w-full h-0.5 bg-white transition-all duration-300 origin-left ${isMenuOpen ? 'rotate-45 translate-x-1' : ''}`}></span>
              <span className={`w-full h-0.5 bg-white transition-all duration-300 ${isMenuOpen ? 'opacity-0' : ''}`}></span>
              <span className={`w-full h-0.5 bg-white transition-all duration-300 origin-left ${isMenuOpen ? '-rotate-45 translate-x-1' : ''}`}></span>
            </div>
          </button>
        </div>
      </div>

      {/* Dropdown Mobile Menu - Appears directly below the navbar */}
      <div className={`absolute left-0 right-0 top-full mt-4 transition-all duration-500 lg:hidden overflow-hidden ${isMenuOpen ? 'max-h-[600px] opacity-100 translate-y-0' : 'max-h-0 opacity-0 -translate-y-4 pointer-events-none'}`}>
        <div className="glass rounded-[32px] p-4 flex flex-col gap-2 shadow-2xl border-white/10">
          {navItems.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              onClick={(e) => handleNavClick(e, item.id)}
              className={`w-full px-6 py-4 rounded-2xl text-sm font-black uppercase tracking-widest transition-all flex justify-between items-center ${
                activeSection === item.id 
                ? 'bg-[#007BFF] text-white shadow-lg' 
                : 'text-gray-400 hover:bg-white/5 hover:text-white'
              }`}
            >
              {item.name}
              {activeSection === item.id && <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>}
            </a>
          ))}
          
          {/* Mobile Socials */}
          <div className="flex gap-2 px-2 mt-2">
            <a 
              href="https://github.com/Abulhassan-pro" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex-1 bg-white/5 py-4 rounded-2xl flex items-center justify-center border border-white/5"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white/50"><path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"></path><path d="M9 18c-4.51 2-5-2-7-2"></path></svg>
            </a>
            <a 
              href="https://www.linkedin.com/in/abul-hassan-844a09378/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex-1 bg-white/5 py-4 rounded-2xl flex items-center justify-center border border-white/5"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-[#0077b5]"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect width="4" height="12" x="2" y="9"></rect><circle cx="4" cy="4" r="2"></circle></svg>
            </a>
          </div>

          <a 
            href="#contact" 
            onClick={(e) => handleNavClick(e, 'contact')}
            className="mt-2 w-full bg-white text-black px-6 py-5 rounded-2xl text-xs font-black uppercase tracking-widest text-center shadow-xl transition-all active:scale-95"
          >
            Start a Project
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;