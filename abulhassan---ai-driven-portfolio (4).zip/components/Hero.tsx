import React, { useState, useEffect } from 'react';

const Hero: React.FC = () => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth - 0.5) * 20;
      const y = (e.clientY / window.innerHeight - 0.5) * 20;
      setMousePos({ x, y });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handleScrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 100,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center pt-20 px-6 overflow-hidden perspective-2000">
      {/* 3D Floating Artifacts in Background */}
      <div className="absolute inset-0 pointer-events-none -z-10 flex items-center justify-center">
        {/* Main 3D Cube Artifact */}
        <div 
          className="relative w-64 h-64 md:w-[600px] md:h-[600px] transition-transform duration-300 ease-out"
          style={{ 
            transform: `rotateX(${-mousePos.y * 1.5}deg) rotateY(${mousePos.x * 1.5}deg)`,
            transformStyle: 'preserve-3d'
          }}
        >
          {/* Animated Wireframe Cube */}
          <div className="absolute inset-0 border border-[#007BFF]/10 animate-[spin_20s_linear_infinite] rounded-full"></div>
          <div className="absolute inset-0 border border-[#007BFF]/5 animate-[spin_35s_linear_infinite_reverse] scale-125"></div>
          
          {/* Floating Points */}
          {[...Array(8)].map((_, i) => (
            <div 
              key={i}
              className="absolute w-2 h-2 bg-[#007BFF] rounded-full blur-[1px] shadow-[0_0_15px_#007BFF]"
              style={{
                transform: `rotateY(${i * 45}deg) translateZ(250px) scale(${1 + Math.sin(i)})`,
                opacity: 0.2
              }}
            ></div>
          ))}
        </div>
      </div>

      {/* Hero Content */}
      <div className="text-center max-w-6xl w-full z-10">
        <div className="flex flex-col items-center">
          {/* Portrait Cluster with 3D Parallax */}
          <div 
            className="relative mb-16 inline-block transition-transform duration-200"
            style={{ transform: `translate(${mousePos.x * 0.5}px, ${mousePos.y * 0.5}px)` }}
          >
            <div className="absolute -inset-12 bg-[#007BFF]/10 blur-3xl animate-pulse rounded-full"></div>
            <div className="absolute -inset-3 border border-white/5 rounded-full animate-[spin_30s_linear_infinite]"></div>
            <div className="absolute -inset-1 border border-[#007BFF]/20 rounded-full"></div>
            
            <div 
              className="relative w-48 h-48 md:w-80 md:h-80 rounded-full p-1.5 bg-gradient-to-tr from-[#007BFF] via-cyan-400 to-transparent overflow-hidden shadow-[0_40px_100px_-20px_rgba(0,123,255,0.4)] animate-float transition-all duration-300"
              style={{ transform: `perspective(1000px) rotateX(${-mousePos.y * 0.8}deg) rotateY(${mousePos.x * 0.8}deg)` }}
            >
               <div className="absolute inset-0 bg-black/10 z-10 pointer-events-none transition-all group-hover:bg-transparent"></div>
               <img 
                src="https://img.sanishtech.com/u/0caae60e7f80d894a87e90796ff86300.png" 
                alt="Abulhassan" 
                className="w-full h-full rounded-full object-cover object-center scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#007BFF]/40 to-transparent mix-blend-overlay"></div>
            </div>
            
            {/* Tag Badge */}
            <div className="absolute bottom-6 -right-6 bg-white text-black px-6 py-2 rounded-full font-black text-[10px] uppercase tracking-[0.2em] shadow-2xl rotate-12 glow-blue z-20 border border-white/20">
              AI Native Expert
            </div>
          </div>

          <div className="inline-block px-6 py-2 rounded-full bg-white/5 border border-white/10 text-[#007BFF] text-[10px] font-black uppercase tracking-[0.5em] mb-12 backdrop-blur-md">
            Architect of Visual Synthesis
          </div>
          
          <h1 
            className="text-6xl md:text-[160px] font-black mb-12 leading-[0.75] tracking-tighter uppercase italic"
            style={{ 
              textShadow: `${mousePos.x * -0.4}px ${mousePos.y * -0.4}px 0px rgba(0, 123, 255, 0.15)`,
              transform: `translateZ(80px)`
            }}
          >
            <span className="text-white block">Abulhassan.</span>
            <span className="gradient-text block mt-4">Visual Alchemist.</span>
          </h1>
          
          <p className="text-lg md:text-2xl text-white/50 font-medium mb-16 max-w-4xl mx-auto leading-relaxed">
            Harnessing the raw power of <span className="text-white">Neural Logic</span> and <span className="text-[#007BFF]">Cinematic Motion</span> to engineer high-fidelity brand experiences.
          </p>
          
          <div className="flex flex-wrap justify-center gap-6">
            <button 
              onClick={() => handleScrollTo('portfolio')} 
              className="group relative px-16 py-6 bg-white text-black rounded-3xl font-black text-xs uppercase tracking-[0.2em] overflow-hidden transition-all hover:scale-105 active:scale-95 shadow-[0_20px_50px_rgba(255,255,255,0.1)]"
            >
              <span className="relative z-10">Explore Works</span>
              <div className="absolute inset-0 bg-[#007BFF] translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
              <span className="absolute inset-0 z-10 flex items-center justify-center opacity-0 group-hover:opacity-100 text-white transition-opacity duration-500">Explore Works</span>
            </button>
            
            <button 
              onClick={() => handleScrollTo('contact')} 
              className="px-16 py-6 glass text-white rounded-3xl font-black text-xs uppercase tracking-[0.2em] hover:bg-white/10 transition-all border-white/10 hover:border-[#007BFF]/50 active:scale-95"
            >
              Start Project
            </button>
          </div>
        </div>
      </div>

      {/* Scroll Down Indicator */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4 opacity-30 animate-pulse">
        <span className="text-[10px] font-black uppercase tracking-[0.4em]">Scroll</span>
        <div className="w-[1px] h-16 bg-gradient-to-b from-[#007BFF] to-transparent"></div>
      </div>

      {/* Decorative Grid Lines with Parallax */}
      <div 
        className="absolute inset-0 -z-20 opacity-[0.04] pointer-events-none transition-transform duration-700 ease-out" 
        style={{ 
          backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', 
          backgroundSize: '100px 100px',
          transform: `scale(1.2) translate(${mousePos.x * 0.3}px, ${mousePos.y * 0.3}px)`
        }}
      ></div>
    </div>
  );
};

export default Hero;