import React, { useState, useRef } from 'react';

const About: React.FC = () => {
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 15;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * -15;
    setTilt({ x, y });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
  };

  return (
    <div className="container mx-auto px-6">
      <div className="flex flex-col lg:flex-row items-center gap-20">
        <div className="w-full lg:w-1/2 perspective-1000">
          <div 
            ref={containerRef}
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            className="relative group transition-transform duration-200 ease-out preserve-3d"
            style={{ transform: `rotateX(${tilt.y}deg) rotateY(${tilt.x}deg)` }}
          >
            <div className="absolute -inset-8 bg-[#007BFF]/20 blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-1000 rounded-[60px]"></div>
            <div className="relative z-10 rounded-[40px] overflow-hidden border border-white/10 shadow-[0_40px_100px_-20px_rgba(0,123,255,0.3)]">
              <img 
                src="https://img.sanishtech.com/u/0caae60e7f80d894a87e90796ff86300.png" 
                alt="Abulhassan Portrait" 
                className="w-full grayscale group-hover:grayscale-0 transition-all duration-1000 cursor-crosshair object-cover aspect-[4/5] scale-105 group-hover:scale-100"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#080808] via-transparent to-transparent opacity-60"></div>
            </div>
            
            <div className="absolute -top-10 -left-10 w-32 h-32 border-t-[6px] border-l-[6px] border-[#007BFF] z-0 opacity-40 group-hover:opacity-100 transition-all duration-700" style={{ transform: 'translateZ(-50px)' }}></div>
            <div className="absolute -bottom-10 -right-10 w-32 h-32 border-b-[6px] border-r-[6px] border-[#007BFF] z-0 opacity-40 group-hover:opacity-100 transition-all duration-700" style={{ transform: 'translateZ(-50px)' }}></div>
            
            <div className="absolute -right-12 top-1/4 glass px-8 py-5 rounded-[24px] z-20 hidden md:block animate-float shadow-2xl border-white/20" style={{ transform: 'translateZ(100px)' }}>
              <p className="text-xs font-black text-[#007BFF] uppercase tracking-widest">Full-Stack Agent</p>
              <p className="text-[10px] text-white/50 uppercase font-bold mt-1">Creative Intel</p>
            </div>
          </div>
        </div>
        
        <div className="w-full lg:w-1/2">
          <span className="text-[#007BFF] font-black uppercase tracking-[0.4em] text-[10px] mb-6 block">Origin Story</span>
          <h2 className="text-5xl md:text-7xl font-black mb-10 tracking-tighter uppercase italic leading-[0.85]">
            Born into the <br /><span className="text-[#007BFF]">AI Native Era.</span>
          </h2>
          
          <div className="space-y-8 text-gray-400 text-xl leading-relaxed font-medium">
            <p>
              I am Abulhassan, an 18-year-old creative powerhouse from Lahore. While others adapt to AI, I was <span className="text-white">digitally native</span> from the start. This gives me an instinctive advantage in merging traditional design with <span className="text-[#007BFF]">Neural Logic</span>.
            </p>
            <p>
              Educated at <span className="text-white">Savvy School</span> and <span className="text-white">Forces College</span>, my foundation is built on both academic rigor and elite professional certifications from <span className="text-[#007BFF]">Bano Qabil</span> and <span className="text-[#007BFF]">Udemy</span>.
            </p>
            <p>
              I bridge the gap between aesthetics and execution. Whether it's crafting a high-fidelity brand or engineering complex <span className="text-white">Web Architectures</span>, my trajectory is fueled by <span className="italic gradient-text">Relentless Excellence.</span>
            </p>
          </div>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="p-8 rounded-[32px] bg-white/5 border border-white/10 group hover:border-[#007BFF]/40 transition-all duration-500 shadow-xl">
              <h4 className="text-[#007BFF] font-black uppercase tracking-[0.3em] text-[11px] mb-6">Technical Core</h4>
              <ul className="space-y-4">
                {["Video Editing Expert", "Digital Marketing Pro", "Python Architect", "Full-Stack Dev", "Graphic Design Lead"].map(skill => (
                  <li key={skill} className="flex items-center gap-4 text-white font-bold text-sm group/li">
                    <span className="w-2 h-2 bg-[#007BFF] rounded-full group-hover/li:scale-150 transition-transform"></span>
                    {skill}
                  </li>
                ))}
              </ul>
            </div>
            <div className="p-8 rounded-[32px] bg-white/5 border border-white/10 group hover:border-[#007BFF]/40 transition-all duration-500 shadow-xl flex flex-col justify-between">
              <div>
                <h4 className="text-[#007BFF] font-black uppercase tracking-[0.3em] text-[11px] mb-6">Strategic Logic</h4>
                <p className="text-gray-400 text-sm leading-relaxed font-medium">
                  Specializing in AI-driven workflows that maximize visual fidelity while maintaining 100% brand consistency. 
                </p>
              </div>
              <div className="mt-8 flex gap-3">
                <span className="text-[10px] bg-[#007BFF]/10 text-[#007BFF] px-4 py-2 rounded-xl font-black uppercase border border-[#007BFF]/20">Lahore Based</span>
                <span className="text-[10px] bg-white/5 text-white/40 px-4 py-2 rounded-xl font-black uppercase border border-white/5">Global Reach</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;