
import React from 'react';

const Footer: React.FC = () => {
  const socials = [
    { 
      name: 'LinkedIn', 
      url: 'https://www.linkedin.com/in/abul-hassan-844a09378/',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect width="4" height="12" x="2" y="9"></rect><circle cx="4" cy="4" r="2"></circle></svg>
      ),
      hoverClass: "hover:text-white hover:bg-[#0077b5] hover:shadow-[0_0_30px_rgba(0,119,181,0.5)]"
    },
    { 
      name: 'GitHub', 
      url: 'https://github.com/Abulhassan-pro',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"></path><path d="M9 18c-4.51 2-5-2-7-2"></path></svg>
      ),
      hoverClass: "hover:text-black hover:bg-white hover:shadow-[0_0_30px_rgba(255,255,255,0.4)]"
    },
    { 
      name: 'WhatsApp', 
      url: 'https://wa.me/923074747291',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
      ),
      hoverClass: "hover:text-white hover:bg-[#25D366] hover:shadow-[0_0_30px_rgba(37,211,102,0.5)]"
    }
  ];

  return (
    <footer className="py-32 border-t border-white/5 bg-radial-at-t from-white/5 to-transparent relative overflow-hidden">
      {/* Decorative background element */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-px bg-gradient-to-r from-transparent via-[#007BFF]/20 to-transparent"></div>

      <div className="container mx-auto px-6 text-center relative z-10">
        <div className="mb-24">
          <h2 className="text-[100px] md:text-[220px] font-black tracking-tighter text-white/[0.02] uppercase select-none leading-none">
            Digital Native
          </h2>
          <div className="-mt-10 md:-mt-24 group">
             <a href="#home" className="text-5xl font-black uppercase tracking-tighter transition-all duration-500 group-hover:tracking-widest">
              ABUL<span className="text-[#007BFF]">HASSAN</span>
            </a>
            <div className="h-0.5 w-12 bg-[#007BFF] mx-auto mt-4 group-hover:w-32 transition-all duration-500"></div>
          </div>
        </div>
        
        {/* Professional Social Hub */}
        <div className="flex justify-center items-center gap-6 md:gap-10 mb-20">
          {socials.map((social) => (
            <a 
              key={social.name} 
              href={social.url} 
              target="_blank"
              rel="noopener noreferrer"
              className={`w-16 h-16 md:w-20 md:h-20 rounded-full glass border-white/10 flex items-center justify-center text-gray-500 transition-all duration-500 transform hover:-translate-y-3 ${social.hoverClass}`}
              aria-label={social.name}
            >
              <div className="transform scale-110 md:scale-125">
                {social.icon}
              </div>
              <span className="absolute -bottom-8 opacity-0 group-hover:opacity-100 text-[10px] font-black uppercase tracking-widest text-white transition-opacity">
                {social.name}
              </span>
            </a>
          ))}
        </div>
        
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 pt-16 border-t border-white/5">
          <div className="flex flex-col items-center md:items-start gap-2">
            <p className="text-gray-600 text-[10px] font-black uppercase tracking-[0.3em]">
              © {new Date().getFullYear()} ARCHITECTED BY ABULHASSAN
            </p>
            <p className="text-white/20 text-[9px] font-bold uppercase tracking-[0.2em]">
              Precision Engineered in Lahore, Pakistan
            </p>
          </div>

          <div className="flex items-center gap-8">
            <a 
              href="mailto:nexelite97@gmail.com" 
              className="text-gray-400 hover:text-[#007BFF] text-xs font-black uppercase tracking-widest transition-colors flex items-center gap-3 group"
            >
              <span className="w-8 h-px bg-white/10 group-hover:w-12 group-hover:bg-[#007BFF] transition-all"></span>
              nexelite97@gmail.com
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
